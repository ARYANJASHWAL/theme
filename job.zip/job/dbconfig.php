<?php
$con=mysqli_connect("localhost","root","","mydata");
//$con=mysqli_connect("localhost","root","saujan","mydata") or die(mysqli_error());
error_reporting(1);
?>